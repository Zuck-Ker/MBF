#!/bin/bash
clear
echo
echo "Tunggu Sampai Proses Selesai Tod Sabar..!"
echo "Ucapkan Yayan Ganteng 3X Biar Work Xixixi:v"
echo
pkg install python
clear
pkg install filet
clear
pkg install ruby -y
clear
gem install lolcat
clear
figlet YayanXD | lolcat
sleep 2
clear
figlet YayanXD | lolcat
sleep 2
clear
echo
echo "██    ██ ██   ██ ███    ██ ███████ " | lolcat
echo " ██  ██  ██   ██ ████   ██    ███  " | lolcat
echo "  ████   ███████ ██ ██  ██   ███   " | lolcat
echo "   ██         ██ ██  ██ ██  ███    " | lolcat
echo "   ██         ██ ██   ████ ███████ " | lolcat
echo
clear
echo
echo "╭╮╮╱▔▔▔▔╲╭╭╮╭╮╮╱▔▔▔▔╲╭╭╮╭╮╮╱▔▔▔▔╲╭╭╮" | lolcat
echo "╰╲╲▏▂╲╱▂▕╱╱╯╰╲╲▏▂╲╱▂▕╱╱╯╰╲╲▏▂╲╱▂▕╱╱╯" | lolcat
echo "┈┈╲▏▇▏▕▇▕╱┈┈┈┈╲▏▇▏▕▇▕╱┈┈┈┈╲▏▇▏▕▇▕╱┈┈" | lolcat
echo "┈┈╱╲▔▕▍▔╱╲┈┈┈┈╱╲▔▕▍▔╱╲┈┈┈┈╱╲▔▕▍▔╱╲┈┈" | lolcat
echo "╭╱╱▕╋╋╋╋▏╲╲╮╭╱╱▕╋╋╋╋▏╲╲╮╭╱╱▕╋╋╋╋▏╲╲╮" | lolcat
echo "╰╯╯┈╲▂▂╱┈╰╰╯╰╯╯┈╲▂▂╱┈╰╰╯╰╯╯┈╲▂▂╱┈╰╰╯" | lolcat
echo
clear
pip2 install -r requirements.txt
clear
pip2 install mechanize
clear
pip2 install requests
clear
python2 mbf.py
