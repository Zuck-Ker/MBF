# MBF
Multi Brute Force
<h1 align="center">
    💀MBF💀
</h1>
<h4 align="center">
  🇮🇩TRICKER INDONESIA🇮🇩
</h4>
<p align="center">
<a href="#"><img title="Author by Yayan" src="https://img.shields.io/badge/Coded%20By-YayanXD-green?"></a>
<a href="#"><img title="Author by YayanXD" src="https://img.shields.io/badge/Code%20-python2.7-blue?"></a>
<br>
<a href="https://github.com/Yayan-XD/followers">
<img title="Followers" src="https://img.shields.io/github/followers/Yayan-XD?label=Followers&color=blue&style=flat-square"></a>
<a href="https://github.com/Yayan-XD/termux-style/stargazers/">
  <a href="https://github.com/Yayan-XD/MBF">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/Yayan-XD/MBF.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/MBF">
    <img alt="Language" src="https://img.shields.io/github/languages/count/Yayan-XD/MBF.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/MBF">
    <img alt="Top Language" src="https://img.shields.io/github/languages/top/Yayan-XD/MBF.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/MBF">
    <img alt="Search" src="https://img.shields.io/github/search/Yayan-XD/Craker/MBF.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/MBF">
    <img alt="Repo Size" src="https://img.shields.io/github/repo-size/Yayan-XD/MBF.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/MBF">
    <img alt="Starts" src="https://img.shields.io/github/stars/Yayan-XD/MBF.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/MBF">
    <img alt="Forks" src="https://img.shields.io/github/forks/Yayan-XD/MBF.svg"/>
  </a>
</div>
<p align="center">

### Install
```
pkg update && pkg upgrade
pkg install git python2
pip2 install --upgrade pip
```
### And MBF this script
```
git clone https://github.com/Yayan-XD/MBF
cd MBF
bash setup.sh
```
### Fitures
<img src="https://github.com/Yayan-XD/MBF/blob/main/Screenshot_20201003_034211.png" />

```
- Multi acc login
- Mutli type login
   - User pass
   - Token
```

## MY SOCIAL MEDIA
[![Github](https://github.com/Zuck-Ker)
[![Twitter](https://img.shields.io/badge/twitter-Ikuti-dark?style=for-the-badge&logo=Twitter)](https://mobile.twitter.com/moch_xd)
[![Facebook](https://img.shields.io/badge/Facebook-Ikuti-dark?style=for-the-badge&logo=facebook)](https://www.facebook.com/YAYAN.XING.ZUCKERBERG.SR)
[![Instagram](https://img.shields.io/badge/Instagram-Ikuti-dark?style=for-the-badge&logo=instagram)](https://Instagram.com/yayanxd_)
* Jika ada yang kurang paham hubungi WhatsApp👇
[![WhatsApp](https://img.shields.io/badge/whatsapp-Hubungi-brightgreen?style=for-the-badge&logo=whatsapp)](https://api.whatsapp.com/send/?phone=%2B6285603036683&text&app_absent=0)
